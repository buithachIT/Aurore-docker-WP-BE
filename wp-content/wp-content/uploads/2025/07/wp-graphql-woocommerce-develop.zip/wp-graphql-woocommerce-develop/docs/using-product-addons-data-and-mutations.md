---
title: "Using Product Add-ons Data + Mutations with WooGraphQL"
author: "Geoff Taylor"
description: "Learn how to use the Product Add-on functionality with WPGraphQL for WooCommerce by building upon the code from `Using Product Data` and `Creating Session Provider and using Cart Mutations`."
keywords: "WooGraphQL, WPGraphQL, WooCommerce, GraphQL, Product Add-on functionality, Product Data, Session Provider, Cart Mutations"
---

# Coming Soon

Sorry, this section is still under development :construction:.